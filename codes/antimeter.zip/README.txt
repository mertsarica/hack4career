ABOUT
-----

This program scans the memory in order to detect and kill Metasploit's meterpreter.
You may check screenshots for more information. (meterpreter_detected.jpg & meterpreter_not_detected.jpg)

USAGE
-----

antimeter.exe <time interval>

	* Antimeter will re-scan memory in every specified time interval.
	* Time interval parameter is optional and default time interval is one minute.

CONTACT
-------

Author: Mert SARICA
Email: mert [ . ] sarica [ @ ] gmail [ . ] com
URL: http://www.mertsarica.com