<?php 
function randString($length, $charset='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789')
{
    $str = '';
    $count = strlen($charset);
    while ($length--) {
        $str .= $charset[mt_rand(0, $count-1)];
    }
    return $str;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Hack 4 Career - http://www.mertsarica.com</title>
<link rel="stylesheet" href="http://www.<?php echo randString(50);?>.com/<?php echo randString(50);?>.css" type="text/css" media="screen" />
<link rel="stylesheet" href="http://www.<?php echo randString(50);?>.com/<?php echo randString(50);?>.css" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="Hack 4 Career RSS Feed" href="http://www.<?php echo randString(50);?>.com/feed/" />
<link rel="alternate" type="application/atom+xml" title="Hack 4 Career Atom Feed" href="http://www.<?php echo randString(50);?>.com/feed/atom/" />
<link rel="pingback" href="http://www.<?php echo randString(50);?>.com/xmlrpc.php" />

<form action="<?php echo randString(50);?>.php" method="post">
 <p><?php echo randString(50);?>: <input type="text" name="<?php echo randString(50); ?>" /></p>
 <p><?php echo randString(50);?>: <input type="text" name="<?php echo randString(50); ?>" /></p>
 <p><input type="submit" /></p>
</form>

function antiscanner($antiscanner)<br \>
{<br \>
    return $antiscanner;<br \>
}<br \>

"/usr/local/<?php echo randString(50);?>"<br \>

"c:/<?php echo randString(50);?>"<br \>

define( 'DB_NAME',     'database' );<br \>
define( 'DB_USER',     'www.mertsarica.com' );<br \>
define( 'DB_PASSWORD', 'antiscanner' );<br \>
define( 'DB_HOST',     'localhost' );<br \>
define( 'DB_CHARSET',  'utf8' );<br \>

<?php echo randString(50);?>@<?php echo randString(50);?>.com<br \>
</html>