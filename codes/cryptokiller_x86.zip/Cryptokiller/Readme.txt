While I was working on a Cryptolocker malware that targeted Turkish users, I decided to create a POC tool called Cryptokiller (tested on Windows 7 Enterprise SP1) which is able to detect and stop the infection and also kills the infected process. I tested it on 5 different Cryptolocker malwares.

I will share the source code of Cryptokiller soon so you will be able to modify it for your needs.

Limitations: 
	Cryptokiller must be running on the operating system before the infection.
	Cryptokiller is able to detect & kill the Cryptolocker process after at least one file is encrypted by Cryptolocker.
	It must be run must under an account with administrator privileges.
	Supports only 32 bit Windows 7 at the moment.

You can run Cryptokiller without GUI by running it with "hidden" parameter. (cryptokiller.exe hidden). You will find the log file inside C:\Cryptokiller folder.

For more info and news about this tool, please visit https://www.mertsarica.com/cryptokiller

       Mert SARICA       
https://www.mertsarica.com
https://twitter.com/mertsarica
https://tr.linkedin.com/in/mertsarica
CISSP, SSCP, OSCP, OPST, CREA & CEREA
