import os
import re
import time
import sys

if sys.platform == 'linux' or sys.platform == 'linux2':
	clearing = 'clear'
else:
	clearing = 'cls'

os.system(clearing)

print "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="
print "| Simple Fuzzer | Mert SARICA | http://www.mertsarica.com |"
print "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-="

target_process = ' "C:\\Program Files\\Webteh\\BSplayer\\bsplayer.exe"'
# target_process = ' "bsplayer.exe"'
target_file = "test.bsi"
seh_handler = "Sehloger.exe"
sleeptime = 1

logger = "SEHLog.txt"

debugger = seh_handler + target_process

variables = ["Version", "Title", "FName", "Sub1", "Font", "SubPos", "FullScreen", "Skin", "Lang", "Aspect", "RunHD", "ExitAtEnd"]

for i in range(0, len(variables)-1):
    
    re1= "(" + variables[i] + ")"
    re2='(=)'	# Any Single Character 1
    re3='((?:\S+))'	# Rest

    readfile = open(target_file, "r")
    tempfile = target_file.split(".")
    tempfile = tempfile[0] + str(i) + "." + tempfile[1]
    
    print "\nTesting:", variables[i] + "\n" 
    
    txt = readfile.read()
    readfile.close()
    
    rg = re.compile(re1+re2+re3,re.IGNORECASE|re.DOTALL)
    m = rg.search(txt)

    if m:
        word1=m.group(1)
        c1=m.group(2)
        word2=m.group(3)        
        entry = word1+c1+word2
        
        for m in range(1,10):
            os.system(debugger)
            time.sleep(sleeptime)
            writefile = open(tempfile, "w")
            bof = word1+c1+(("A"*128)*m)

            text = txt.replace(entry, bof)
            writefile.write(text)
            writefile.close()
            
            bof_check = target_process + " " + tempfile
            os.system(bof_check)
            time.sleep(sleeptime)

            logfile = open(logger, "r")
            log = logfile.read()

            if log.find("41414141") > 0:
                print "\nGray area detected, responsible disclosure or dark side padawan? :)\a\n"
                print "Suspicious file:", (tempfile)
                sys.exit()

            os.system("taskkill.exe /IM bsplayer.exe")
            time.sleep(sleeptime)
