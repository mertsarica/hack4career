# Keylogger SMTP Password Scanner
# Author: Mert SARICA
# E-mail: mert [ . ] sarica [ @ ] gmail [ . ] com
# URL: http://www.mertsarica.com

import re
import os
import sys
import time

os.system("cls")

def find_email_and_password(filename):
	try:
		FILE  = open (filename, "r" )   
		txt = FILE.readlines()
		FILE.close()
	except IOError:
		print "[+] %s file not found!\n" % (sys.argv[1])
		sys.exit(1)

        command = "strings.exe " + sys.argv[1] + " > forensic.txt"
	print "[+] Running command:", command
	os.system(command)
	
        print "[+] Sleeping 15 seconds..."
        time.sleep(10)
        
        filename = "forensic.txt"
	try:
		FILE  = open (filename, "r" )   
		txt = FILE.read()
		FILE.close()
	except IOError:
		print "[+] %s file not found!\n" % (sys.argv[1])
		sys.exit(1)

	# For Eslogger Detection
        re1='(\\[#\\])'	# Square Braces 1
        re2='([\\w-]+(?:\\.[\\w-]+)*@(?:[\\w-]+\\.)+[a-zA-Z]{2,7})'	# Email Address 1      
        re3='(\\[#\\])'	# Square Braces 2
        re4='((?:[a-z][a-z0-9_]*))'	# Variable Name 1
        re5='(\\[#\\])'	# Square Braces 3
        re6='([\\w-]+(?:\\.[\\w-]+)*@(?:[\\w-]+\\.)+[a-zA-Z]{2,7})'	# Email Address 2
        re7='(\\[#\\])'	# Square Braces 4

        rg = re.compile(re1+re2+re3+re4+re5+re6+re7,re.IGNORECASE|re.DOTALL)
        m = rg.search(str(txt))
        if m:
            email1=m.group(2)
            var1=m.group(4)
            email2=m.group(6)
            print "\n[+] Eslogger Detected!"
            print "[*] E-mail address: %s \n[*] Password: %s" % (email1, var1)
            print "\n[+] Deleting forensic.txt file"
            print "[+] Enjoy your new mail box :)"
            os.system("del forensic.txt")
            sys.exit(1)
            # print email1+" "+" "+var1+" "+" "+email2+"\n"
            
        # For Perfect Keylogger Detection
        re1='^(.+)\n'
        re2='^(.+)\n'
        re3='([\\w-]+(?:\\.[\\w-]+)*@(?:[\\w-]+\\.)+[a-zA-Z]{2,7})'	# Email Address 1
        rg = re.compile(re1+re2+re3,re.IGNORECASE|re.MULTILINE)
        m = rg.search(str(txt))
        if m:
            username=m.group(1)
            password=m.group(2)
            email1=m.group(3)
            print "\n[+] Perfect Keylogger Detected!"
            print "[*] E-mail address: %s \n[*] Username: %s \n[*] Password: %s" % (email1, username, password)
            print "\n[+] Deleting forensic.txt file"
            print "[+] Enjoy your new mail box :)"
            os.system("del forensic.txt")
            sys.exit(1)

        # Add your new detection method here

        # end

        os.system("del forensic.txt")
        print "[+] Nothing found :("
        
if __name__ == '__main__': 	
	print "==========================================================="
	print u"Keylogger SMTP Password Scanner [http://www.mertsarica.com]"
	print "==========================================================="
	if len(sys.argv) < 2:
		print "Usage: python ksps.py [dump file]\n"
		sys.exit(1)
	
	try:
		find_email_and_password(sys.argv[1])
	except KeyboardInterrupt:
		os.system("cls")
		print "==========================================================="
		print u"Keylogger SMTP Password Scanner [http://www.mertsarica.com]"
		print "==========================================================="		
		print "[+] Bye..."
