ABOUT
-----

This program intends to detect a malicious file in two ways; online and offline.
It calculates the md5 hash of a specified file and searches it in its current hash set (offline) or on virustotal site (online) and show the result.
It has http proxy support and update (for hash set) feature.
Coded for fun so enjoy it :)


CHANGELOG
---------
v1.3 - Online check output shows antivirus name. 
v1.2 - New Virustotal changes implemented.
v1.1 - Wrong implementation of md5 calculation fixed. (Credit goes to roynal [.] smith [@] gmail [.] com)


USAGE
-----

python malware_check.py update

	* This command updates its current hash set (hashset.txt) by crawling threat information from http://www.avira.ro
	* Hashset.txt includes virus name, virus type, md5 hash of the virus, severity and discovered date.
	* If there is no hashset.txt file, it will visit http://www.avira.ro and start gathering virus name, 
          virus type, virus md5, severity and discovered date
	* If there is a hashset.txt it just up to date its current hash set to the latest.

python malware_check.py online malware.exe

	* This command calculates the md5 hash of a specified file (ex: malware.exe), submits it to http://www.virustotal.com
	  and then shows the result. 

python malware_check.py offline malware.exe
	* This command takes the md5 hash of the specified file (ex: malware.exe) and searches it in its current hash set (hashset.txt)
	  and then shows the result.


Note: For http proxy support you have to edit malware_check.py and modify the required fields as shown below.

	proxy_info = {
	'user' : 'username', # proxy username
	'pass' : 'password', # proxy password
	'host' : "proxy host", # proxy host
	'port' : 8080 # proxy port
	}


CONTACT
-------

Author: Mert SARICA
Email: mert [ . ] sarica [ @ ] gmail [ . ] com
URL: http://www.mertsarica.com